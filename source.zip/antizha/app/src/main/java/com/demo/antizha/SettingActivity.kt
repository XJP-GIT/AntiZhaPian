package com.demo.antizha

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingActivity: AppCompatActivity() {
    
    lateinit var settings:SharedPreferences
    lateinit var editor:SharedPreferences.Editor
    
    @SuppressLint("CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mine_setting_info)

        val setCommit:Button = findViewById(R.id.set_commit)
        val setClear:Button = findViewById(R.id.set_clear)
        val resetButton:Button = findViewById(R.id.set_reset)
        val generalName:ImageButton = findViewById(R.id.set_load_name)
        val generalId:ImageButton = findViewById(R.id.set_load_id)
        val generalWork:ImageButton = findViewById(R.id.set_load_work)

        val setName:EditText = findViewById(R.id.set_name)
        val setId:EditText = findViewById(R.id.set_id)
        val setRegion:EditText = findViewById(R.id.set_region)
        val setAddress:EditText = findViewById(R.id.set_address)
        val setWork:EditText = findViewById(R.id.set_work)

        setCommit.setOnClickListener {
            when {
                setName.text.toString() == "" -> {
                    Toast.makeText(this@SettingActivity, "名字不能为空。", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                setId.text.toString() == "" -> {
                    Toast.makeText(this@SettingActivity, "证件号不能为空。", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                setRegion.text.toString() == "" -> {
                    Toast.makeText(this@SettingActivity, "地区不能为空。", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                setAddress.text.toString() == "" -> {
                    Toast.makeText(this@SettingActivity, "详细地址不能为空。", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                setWork.text.toString() == "" -> {
                    Toast.makeText(this@SettingActivity, "行业不能为空。", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                else -> {
                    settings = getSharedPreferences("setting", 0)
                    editor = settings.edit()
                    editor.putString("name", setName.text.toString() + "** ")
                    editor.putString("id", setId.text.toString()[0] + "****************" + setId.text.toString()[1])
                    editor.putString("region", setRegion.text.toString())
                    editor.putString("address", setAddress.text.toString())
                    editor.putString("work", setWork.text.toString())
                    editor.apply()
                    Toast.makeText(this@SettingActivity, "成功", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }

        setClear.setOnClickListener {
            setName.text = null
            setId.text = null
            setRegion.text = null
            setAddress.text = null
            setWork.text = null
        }

        resetButton.setOnClickListener {
            settings = getSharedPreferences("setting", 0)
            editor = settings.edit()
            editor.remove("name")
            editor.remove("id")
            editor.remove("region")
            editor.remove("address")
            editor.remove("work")
            editor.commit()
            Toast.makeText(this@SettingActivity, "成功", Toast.LENGTH_SHORT).show()
            finish()
        }

        generalName.setOnClickListener {
            val seed = listOf<String>("王", "李", "张", "刘", "陈", "杨", "黄", "赵", "吴", "周", "徐",
                    "孙", "马", "朱", "胡", "郭", "何", "高", "林", "郑", "谢", "罗", "梁", "宋", "唐",
                    "许", "韩", "冯", "邓", "曹", "彭", "曾", "蕭", "田", "董", "袁", "潘", "于", "蒋",
                    "蔡", "余", "杜", "叶", "程", "苏", "魏", "吕", "丁", "任", "沈", "姚", "卢", "姜",
                    "崔", "钟", "谭", "陆", "汪", "范", "金", "石", "廖", "贾", "夏", "韦", "付", "方",
                    "白", "邹", "孟", "熊", "秦", "邱", "江", "尹", "薛", "闫", "段", "雷", "侯", "龙",
                    "史", "陶", "黎", "贺", "顾", "毛", "郝", "龚", "邵", "万", "钱", "严", "覃", "武",
                    "戴", "莫", "孔", "向", "汤").random()
            setName.setText(seed)
        }

        generalId.setOnClickListener {
            val seed = (10..99).random().toString()
            setId.setText(seed)
        }

        generalWork.setOnClickListener {
            val seed = listOf<String>("衣、林、牧、渔业", "金融、保险、投资", "房地产业", "教育、学生",
                    "建筑业", "住宿和餐饮业", "采矿业", "旅游、购物、休闲", "工艺品、礼品",
                    "党政机关、社会团体", "家具、生活用品、食品", "新闻、出版、科研", "机械设备、通用零部件",
                    "广告、会展、商务办公、咨询", "公共管理、社会保障和社会组织", "卫生和社会工作", "制造业")
                    .random()
            setWork.setText(seed)
        }

    }

}