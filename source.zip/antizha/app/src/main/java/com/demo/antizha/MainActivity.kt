package com.demo.antizha

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.forEach
import androidx.navigation.findNavController
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_main)
        val navView: BottomNavigationView = findViewById(R.id.nav_view)

        val navController = findNavController(R.id.nav_host_fragment)

        navView.itemBackground = null

        navView.menu.forEach {
            val view = navView.findViewById<View>(it.itemId)
            view.setOnLongClickListener { true }
        }

        navView.setOnNavigationItemSelectedListener { item ->
            resetIcon(navView)
            when(item.itemId){
                R.id.navigation_home -> {
                    item.setIcon(R.drawable.ic_home_seled)
                    navController.navigate(R.id.navigation_home)
                    true
                }
                R.id.navigation_dashboard -> {
                    item.setIcon(R.drawable.ic_dashboard_seled)
                    navController.navigate(R.id.navigation_dashboard)
                    true
                }
                R.id.navigation_notifications -> {
                    item.setIcon(R.drawable.ic_mine_seled)
                    navController.navigate(R.id.navigation_notifications)
                    true
                }
                else -> false
            }
        }
    }

    private fun resetIcon(navView:BottomNavigationView) {
        val home =  navView.menu.findItem(R.id.navigation_home)
        val dashboard = navView.menu.findItem(R.id.navigation_dashboard)
        val mine = navView.menu.findItem(R.id.navigation_notifications)
        home.setIcon(R.drawable.ic_home_unseled)
        dashboard.setIcon(R.drawable.ic_dashboard_unseled)
        mine.setIcon(R.drawable.ic_mine_unseled)
    }
}