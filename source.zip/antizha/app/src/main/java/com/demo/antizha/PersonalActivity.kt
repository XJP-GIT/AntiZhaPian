package com.demo.antizha

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PersonalActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.personal_info)

        val name:TextView = findViewById(R.id.info_name)
        val id:TextView = findViewById(R.id.id)
        val region:TextView = findViewById(R.id.region)
        val address:TextView = findViewById(R.id.address)
        val work:TextView = findViewById(R.id.work)
        val settings: SharedPreferences = getSharedPreferences("setting", 0)

        name.text = settings.getString("name", "周** ")
        id.text = settings.getString("id", "4****************8")
        region.text = settings.getString("region", "广东省.深圳市.龙岗区")
        address.text = settings.getString("address", "龙岗中心城福宁路113号")
        work.text = settings.getString("work", "电子设备制造")
    }
}